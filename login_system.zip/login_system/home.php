<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
    <link rel="shortcut icon" href="assets/leaf.ico"/>
	<style type="text/css">
	body {
	background-color: #FF9966;
	background-image: url(assets/Beautiful%20Quotes%20Desktop%20Wallpaper.png);
}
    </style>
<meta charset="utf-8">
</head>
<body>
<h1>Welcome, <?php echo $_SESSION['name']; ?></h1>
     <a href="index_main.php">Dashboard</a>
<pre></pre>
<a href="logout.php">Logout</a>
     
</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>