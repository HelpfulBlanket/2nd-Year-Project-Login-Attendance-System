<!DOCTYPE html>
<html>
<head>
	<title>Time In</title>
	<link rel="stylesheet" type="text/css" href="style.css">
    <link rel="shortcut icon" href="assets/leaf.ico"/>
	<style type="text/css">
	body {
	background-image: url(assets/Green%20and%20Peach%20Botanic%20Room%20Minimalist%20Desktop%20Wallpaper.png);
	background-repeat: no-repeat;
}
    </style>
<meta charset="utf-8">
</head>
<body>
     <form action="login.php" method="post">
     	<h2>ATTENDANCE TIME IN&nbsp;&nbsp;</h2>
     	<?php if (isset($_GET['error'])) { ?>
   		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
     	<label>Username</label>
     	<input type="text" name="uname" placeholder="Username"><br>

     	<label>Password</label>
     	<input type="password" name="password" placeholder="Password"><br>

     	<button type="submit">Login</button>
     </form>
</body>
</html>