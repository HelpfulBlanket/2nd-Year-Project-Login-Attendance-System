<?php 
	session_start();
	// initialize variables
	$instructorid = "";
	$fname = "";
	$mname = "";
	$lname = "";
	$gender = "";
	$date = "";
	$login_time = "";
	$logout_time = "";
	$cid = 0;
	$edit_state = false;
	
	// connect to database
	$db = mysqli_connect('localhost', 'root', '', 'learningmods');
	
	//if save button is clicked
	if (isset($_POST['save'])) {
		$instructorid = $_POST['instructorid'];
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$lname = $_POST['lname'];
		$gender = $_POST['gender'];
		$date = $_POST['date'];
		$login_time = $_POST['login_time'];
		$logout_time = $_POST['logout_time'];
		
		$query = "INSERT INTO instructordata (instructorid, fname, mname, lname, gender, date, login_time, logout_time) VALUES ('$instructorid', '$fname', '$mname', '$lname', '$gender', '$date', '$login_time', '$logout_time')";
		mysqli_query($db, $query);
		$_SESSION['msg'] = "Information saved";
		header('location: body.php'); // redirect to index page after inserting
	}
	
	// update records
	if (isset($_POST['update'])) {
		$cid = mysqli_real_escape_string($_POST['cid']);
		$instructorid = mysqli_real_escape_string($_POST['instructorid']);
		$fname = mysqli_real_escape_string($_POST['fname']);
		$mname = mysqli_real_escape_string($_POST['mname']);
		$lname = mysqli_real_escape_string($_POST['lname']);
		$gender = mysqli_real_escape_string($_POST['gender']);
		$date = mysqli_real_escape_string($_POST['date']);
		$login_time = mysqli_real_escape_string($_POST['login_time']);
		$logout_time = mysqli_real_escape_string($_POST['logout_time']);
		mysqli_query($db, "UPDATE instructordata SET instructorid='$instructorid', fname='$fname', mname='$mname', lname='$lname', gender='$gender', date='$date', login_time='$login_time', logout_time='$logout_time' WHERE cid=$cid");
		$_SESSION['msg'] = "Information updated";
		header('location: body.php');
	}
	
	// delete records
	if (isset($_GET['del'])) {
		$cid = $_GET['del'];
		mysqli_query($db, "DELETE FROM instructordata WHERE cid=$cid");
		$_SESSION['msg'] = "Information deleted";
		header('location: body.php');
	}
	
	// retrieve records
	$results =  mysqli_query($db, "SELECT * FROM instructordata");
	
	?>