<?php
	$con = mysqli_connect('localhost','root','','learningmods');
	if (isset($_GET['submit'])) {
		$title = $_GET['text'];
		$sql = "SELECT * FROM instructordata WHERE instructorid LIKE '%$instructorid%'";
		$exe = mysqli_query($con,$sql)or die("Query Failed!");
		if (mysqli_num_rows($exe) > 0){
			$count=0;
			while ($row = mysqli_fetch_assoc($exe)){
				$count++

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width", initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>hahahah</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
	<table id="main" border="0" cellspacing="0">
    	<tr>
        	<td id="header">
            	<h1>Search in PHP</h1>
            </td>
        </tr>
        <tr>
        	<td id="table-form">
            	<form action="assets/search.php" method="get">
                	Search : <input type="text" name="text" value="search">
                    <input type="submit" name="submit" value="search">
                </form>
            </td>
        </tr>
        <tr>
        	<td id="table-data">
            	<table cellpadding="10px">
                  <tr>
                    <th>instructorid</th>
                    <th width="300">fname</th>
                    <th width="400">mname</th>
                    <th width="300">lname</th>
                    <th width="300">gender</th>
                    <th width="300">date</th>
                    <th width="300">login_time</th>
                    <th width="300">logout_time</th>
                  </tr>
                  <tr>
                  <td>
                  	<?php echo $count; ?>
                  </td>
                  <td>
                  	<?php echo $row['instructorid']; ?>
                  </td>
                  <td>
                  	<?php echo $row['fname']; ?>
                  </td>
                  <td>
                  	<?php echo $row['mname']; ?>
                  </td>
                  <td>
                  	<?php echo $row['lname']; ?>
                  </td>
                  <td>
                  	<?php echo $row['gender']; ?>
                  </td>
                  <td>
                  	<?php echo $row['date']; ?>
                  </td>
                  <td>
                  	<?php echo $row['login_time']; ?>
                  </td>
                  <td>
                  	<?php echo $row['logout_time']; ?>
                  </td>
                  </tr>
              	</table>
            </td>
        </tr>
	</table>
</body>
</html>
<?php }}} ?>