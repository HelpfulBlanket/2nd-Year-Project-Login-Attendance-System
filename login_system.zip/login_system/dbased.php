<!doctype html>
<html>
<head>
</head>
<body>
<table width="1327">
	<tr>
		<th>instructorid</th>
		<th>fname</th>
		<th>mname</th>
		<th>lname</th>
		<th>gender</th>
		<th>date</th>
		<th>login time</th>
		<th>logout time</th>
	</tr>
	<?php
	$conn = mysqli_connect("localhost", "root", "", "learningmods");
	if ($conn-> connect_error) {
		die("Connetion failed:" . $conn-> connect_error);
	}
	
	$sql = "SELECT instructorid, fname, mname, lname, gender, date, login time, logout time from instructordata";
	$result = $conn-> query($sql);
	
	if ($result-> num_rows > 0) {
		while ($row = $result-> fetch_assoc()) {
			echo "<tr><td>". $row["instructorid"] ."</td><td>". $row["fname"] ."</td><td>". $row["mname"] ."</td><td>". $row["lname"] ."</td><td>". $row["gender"] ."</td><td>". $row["date"] ."</td><td>". $row["login time"] ."</td><td>". $row["logout time"] ."</td></tr>";
		}
		echo "</table>";
	}
	else{
		echo "0 result";
	}
	
	$conn-> close();
	?>

</table>	
</body>
</html>