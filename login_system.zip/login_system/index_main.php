<doctype html>
<html>
<head>
	<title>Main Page</title>
<style type="text/css">
.style5 {
	font-family: Verdana, Geneva, sans-serif;
}
</style>
</head>
<meta charset="iso-8859-1">
<title>Unitled Document</title>
<style type="text/css">
<!--
.style3 {
	color: #000000;
	font-size: 36px;
	font-weight: bold;
}
.style4 {color: #FFFFFF}
body {
	background-color: #FFFFFF;
	background-image: url(th.jfif);
}
.style5 {
	font-family: Verdana, Geneva, sans-serif;
}
.style5 {
	font-size: 36px;
}
.style5 {
	font-weight: bold;
}
.style4 a {
	font-family: Verdana, Geneva, sans-serif;
}
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>

<body bgcolor="#CCCC99">
<p>&nbsp;</p>
<table width="1252" height="98" align="center">
  <tr>
    <td colspan="2" bgcolor="#00CC99"><div align="center" class="style5"> DASHBOARD </div></td>
  </tr>
  <tr>
    <td width="591" bgcolor="#FFFFFF"><div align="center" class="style4"><a href="logout.php">LOGOUT </a></div></td>
    <td width="635" bgcolor="#FFFFFF"><div align="center" class="style4">
      <div align="center"><a href="body.php">INSERT NEW RECORD</a> </div>
    </div></td>
  </tr>
  <tr>
    <td height="21" colspan="2"</td>
    
    
  </tr>
  
</table>

<form method="post"> 
<label><img src="assets/search.png" align="center" width="21" height="21" alt="search icon"></label>
<input type="text" name="search" placeholder="Instructor ID">
<input type="submit" name="submit">
	
</form>

<?php

$con = new PDO("mysql:host=localhost;dbname=learningmods",'root','');

if (isset($_POST["submit"])) {
	$str = $_POST["search"];
	$sth = $con->prepare("SELECT * FROM `instructordata` WHERE instructorid = '$str'");

	$sth->setFetchMode(PDO:: FETCH_OBJ);
	$sth -> execute();

	if($row = $sth->fetch())
	{
		?>
		<br><br><br>
		<table>
			<tr>
            <table width="1301" border="2" align="center" cellpadding="5" cellspacing="2">
            <tr bgcolor="#CCCC99" class="instructorid">
				<th>instructorid</th>
				<th>fname</th>
                <th>mname</th>
                <th>lname</th>
                <th>gender</th>
                <th>date</th>
                <th>login_time</th>
                <th>logout_time</th>
			</tr>
			<tr>
				<td><?php echo $row->instructorid; ?></td>
				<td><?php echo $row->fname;?></td>
                <td><?php echo $row->mname; ?></td>
                <td><?php echo $row->lname; ?></td>
                <td><?php echo $row->gender; ?></td>
                <td><?php echo $row->date; ?></td>
                <td><?php echo $row->login_time; ?></td>
                <td><?php echo $row->logout_time; ?></td>
			</tr>

		</table>
<?php 
	}
		
		
		else{
			echo "Name Does not exist";
		}


}

?>




<pre></pre>

<style type="text/css">
.instructorid {
	font-family: Arial, Helvetica, sans-serif;
}
.instructorid {
	font-family: Verdana, Geneva, sans-serif;
}
.instructorid {
	color: #336;
}
</style>

<table width="1301" border="2" align="center" cellpadding="5" cellspacing="2">
	<tr bgcolor="#00CC99" class="instructorid">
		<th width="7" height="20" bgcolor="#00CC99" class="instructorid">instructorid</th>
		<th width="7" height="20">fname</th>
		<th width="7" height="20">mname</th>
	  <th width="7" height="20">lname</th>
		<th width="7" height="20" bgcolor="#00CC99">gender</th>
		<th width="7" height="20" bgcolor="#00CC99">date</th>
		<th width="7" height="20">login time</th>
		<th width="7" height="20">logout time</th>
  </tr>
	<?php
	$conn = mysqli_connect("localhost", "root", "", "learningmods");
	if ($conn-> connect_error) {
		die("Connetion failed:" . $conn-> connect_error);
	}
	
	$sql = "SELECT instructorid, fname, mname, lname, gender, date, login_time, logout_time from instructordata";
	$result = $conn-> query($sql);
	
	if ($result-> num_rows > 0) {
		while ($row = $result-> fetch_assoc()) {
			echo "<tr><td>". $row["instructorid"] ."</td><td>". $row["fname"] ."</td><td>". $row["mname"] ."</td><td>". $row["lname"] ."</td><td>". $row["gender"] ."</td><td>". $row["date"] ."</td><td>". $row["login_time"] ."</td><td>". $row["logout_time"] ."</td></tr>";
		}
		echo "</table>";
	}
	else{
		echo "0 result";
	}
	
	$conn-> close();
	?>

</table>
<p>&nbsp;</p>
</body>
</html>