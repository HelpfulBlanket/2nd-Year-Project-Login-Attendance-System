<?php include('server.php'); 

// fetch the record to be updated
if (isset($_GET['edit'])) {
	$id = $_GET['edit'];
	$edit_state = true;
	$rec = mysqli_query($db, "SELECT * FROM instructordata WHERE cid=$cid");
	$record = mysqli_fetch_array($rec);
	$instructorid = $record['instructorid'];
	$fname = $record['fname'];
	$mname = $record['mname'];
	$lname = $record['lname'];
	$gender = $record['gender'];
	$date = $record['date'];
	$login_time = $record['login_time'];
	$logout_time = $record['logout_time'];
	$cid = $record['cid'];

}


?>
<!DOCTYPE html>
<html>
<head>
	<title>Holy</title>
    <link rel="stylesheet" type="text/css" href="style1.css">
    <style type="text/css">
    body {
	background-image: url(login_images/sad.jpg);
}
    </style>
<meta charset="utf-8">
</head>
<body>

<body>
<?php if (isset($_SESSION['message'])): ?>
	<div class="msg">
		<?php 
			echo $_SESSION['message']; 
			unset($_SESSION['message']);
		?>
	</div>
<?php endif ?>
	<table width="66%" align="center">
    	<thead>
        	<tr>
            	<th bgcolor="#ADE8EB">instructorid</th>
                <th bgcolor="#ADE8EB">fname</th>
                <th bgcolor="#D196F3">mname</th>
                <th bgcolor="#DBEFC0">lname</th>
                <th bgcolor="#D196F3">gender</th>
                <th bgcolor="#D196F3">date</th>
                <th bgcolor="#DBEFC0">login_time</th>
                <th bgcolor="#DBEFC0">logout_time</th>
                <th colspan="7" bgcolor="#DBEFC0">Action</th>
              </tr>
              </thead>
              <tbody>
              		<?php while ($row = mysqli_fetch_array($results)) { ?>
					<tr>
                		<td><?php echo $row['instructorid']; ?></td>
                   	 	<td><?php echo $row['fname']; ?></td>
                    	<td><?php echo $row['mname']; ?></td>
                    	<td><?php echo $row['lname']; ?></td>
                    	<td><?php echo $row['gender']; ?></td>>
                    	<td><?php echo $row['date']; ?></td>
                    	<td><?php echo $row['login_time']; ?></td>
                        <td><?php echo $row['logout_time']; ?></td>
                    	<td bgcolor="#FFFFFF">
                    	<a class="edit_btn" href="body.php?edit=<?php echo $row['cid']; ?>">Edit</a>
                        </td>
                        <td>
                        <a class="del_btn" href="server.php?del=<?php echo $row['cid']; ?>">Delete</a>
                    </td>
                   </tr>
					<?php } ?>
              	
                 </tbody>
                </table>
	<p><a href="logout.php">LOGOUT</a></p>
               </body>
<form method="post" action="server.php" >
    <input type="hidden" name="id" value="<?php echo $id; ?>">
		<div class="input-group">
			<label>instructorid</label>
			<input type="text" name="instructorid" value="<?php echo $instructorid; ?>">
		</div>
		<div class="input-group">
			<label>fname</label>
			<input type="text" name="fname" value="<?php echo $fname; ?>">
		</div>
        <div class="input-group">
			<label>mname</label>
			<input type="text" name="mname" value="<?php echo $mname; ?>">
		</div>
        <div class="input-group">
			<label>lname</label>
			<input type="text" name="lname" value="<?php echo $lname; ?>">
		</div>
        <div class="input-group">
			<label>gender</label>
			<input type="text" name="gender" value="<?php echo $gender; ?>">
		</div>
        <div class="input-group">
			<label>date</label>
			<input type="text" name="date" value="<?php echo $date; ?>">
		</div>
        <div class="input-group">
			<label>login time</label>
			<input type="text" name="login_time" value="<?php echo $login_time; ?>">
		</div>
        <div class="input-group">
			<label>logout time</label>
			<input type="text" name="logout_time" value="<?php echo $logout_time; ?>">
		</div>
		<div class="input-group">
        <?php if ($edit_state == false): ?>
        <button type="submit" name="save" class="btn">Save</button>
        <?php else: ?>
        <button type="submit" name="update" class="btn">Update</button>
        <?php endif ?>
			
		</div>
	</form>
    
</body>
</html>