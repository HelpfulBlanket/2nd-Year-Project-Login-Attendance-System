<?php

$host = "localhost";
$user = "root";
$password ="";
$database = "learningmods";

$cid = "";
$instructorid = "";
$fname = "";
$mname = "";
$lname = "";
$gender = "";
$date = "";
$login_time = "";
$logout_time = "";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// connect to mysql database

try{
	$db = mysqli_connect($host, $user, $password, $database);
} catch (Exception $ex) {
	echo 'Error';
}

// get values from the form
function getPosts()
{
	$posts = array();
	$posts[0] = $_POST['cid'];
	$posts[1] = $_POST['instructorid'];
	$posts[2] = $_POST['fname'];
	$posts[3] = $_POST['mname'];
	$posts[4] = $_POST['lname'];
	$posts[5] = $_POST['gender'];
	$posts[6] = $_POST['date'];
	$posts[7] = $_POST['login_time'];
	$posts[8] = $_POST['logout_time'];
	return $posts;
}

// Search

if(isset($_POST['search']))
{
	$data = getPosts();
	
	$search_Query = "SELECT * FROM instructordata WHERE cid = $data[0]";
	
	$search_Result = mysqli_query($db, $search_Query);
	
	if($search_Result)
	{
		if(mysqli_num_rows($search_Result))
		{
			while($row = mysqli_fetch_array($search_Result))
			{
				$cid = $row['cid'];
				$instructorid = $row['instructorid'];
				$fname = $row['fname'];
				$mname = $row['mname'];
				$lname = $row['lname'];
				$gender = $row['gender'];
				$date = $row['date'];
				$login_time = $row['login_time'];
				$logout_time = $row['logout_time'];
				
			}
		}else{
			echo 'Error data, Please Write Correctly';
		}
	}else{
		echo 'Result Error, Please Try Again';
	}
}

// Insert
if(isset($_POST['insert']))
{
	$data = getPosts();
	$insert_Query = "INSERT INTO `instructordata`(`instructorid`, `fname`, `mname`, `lname`, `gender`, `date`, `login_time`, `logout_time`) VALUES ('$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]',$data[8])";
	try{
		$insert_Result = mysqli_query($db, $insert_Query);
		
		if($insert_Result)
		{
			if(mysqli_affected_rows($db) > 0)
			{
				echo 'Data Inserted';
			}else{
				echo 'Data Not Inserted';
			}
		}
	} catch (Exception $ex) {
		echo 'Error Insert '.$ex->getMessage();
	}
}

// Delete
if(isset($_POST['delete']))
{
    $data = getPosts();
    $delete_Query = "DELETE FROM `instructordata` WHERE `cid` = $data[0]";
    try{
        $delete_Result = mysqli_query($db, $delete_Query);
        
        if($delete_Result)
        {
            if(mysqli_affected_rows($connect) > 0)
            {
                echo 'Data Deleted';
            }else{
                echo 'Data Not Deleted';
            }
        }
    } catch (Exception $ex) {
        echo 'Error Delete '.$ex->getMessage();
    }
}

// Update
if(isset($_POST['update']))
{
    $data = getPosts();
    $update_Query = "UPDATE `instructordata` SET `instructorid`='$data[1]',`fname`='$data[2]',`mname`=$data[3],`lname`=$data[4],`gender`=$data[5],`date`=$data[6],`login_time`=$data[7],`logout_time`=$data[8] WHERE `cid` = $data[0]";
    try{
        $update_Result = mysqli_query($db, $update_Query);
        
        if($update_Result)
        {
            if(mysqli_affected_rows($db) > 0)
            {
                echo 'Data Updated';
            }else{
                echo 'Data Not Updated';
            }
        }
    } catch (Exception $ex) {
        echo 'Error Update '.$ex->getMessage();
    }
}




?>

<!doctype html>
<html>
<head>
		<title>Insert,Update and Delete</title>
</head>
	<body>
	<form action="query.php" method="post">
  	  <input type="number" name="cid" placeholder="No." value="<?php echo $cid;?>"><br></br>
      <input type="varchar" name="instructorid" placeholder="ID" value="<?php echo $instructorid;?>"><br></br>
      <input type="text" name="fname" placeholder="First Name" value="<?php echo $fname;?>"><br></br>
      <input type="text" name="mname" placeholder="Middle Name" value="<?php echo $mname;?>"><br></br>
      <input type="text" name="lname" placeholder="Last Name" value="<?php echo $lname;?>"><br></br>
      <input type="text" name="gender" placeholder="Gender" value="<?php echo $gender;?>"><br></br>
      <input type="varchar" name="date" placeholder="Date" value="<?php echo $date;?>"><br></br>
      <input type="varchar" name="login_time" placeholder="Time In" value="<?php echo $login_time;?>"><br></br>
      <input type="varchar" name="logout_time" placeholder="Time Out" value="<?php echo $logout_time;?>"><br></br>
      <div>
        	<input type="submit" name="insert" value="Insert">
        	<input type="submit" name="update" value="Update">
        	<input type="submit" name="delete" value="Delete">
            <input type="submit" name="search" value="Search">
      </div>
      </form>
	</body>
</html>