<!doctype html>
<html>
<head>
<title>Database Table</title>
<link rel="shortcut icon" href="assets/leaf.ico"/>
<style type="text/css">
.instructorid {
	font-family: Arial, Helvetica, sans-serif;
}
.instructorid {
	font-family: Verdana, Geneva, sans-serif;
}
.instructorid {
	color: #336;
}
body {
.style5 {
	font-family: Verdana, Geneva, sans-serif;
}
.style5 {
	font-size: 36px;
}
.style5 {
	font-weight: bold;
}
	background-image: url(assets/Green%20and%20Peach%20Botanic%20Room%20Minimalist%20Desktop%20Wallpaper.png);
}
</style>
<meta charset="utf-8">
</head>
<body bgcolor="#CCCC99" text="#003333">

<a href="index_main.php"><img src="assets/back button.png" width="34" height="34" alt="back button" longdesc="assets/back button.png"></a>

<td colspan="2" bgcolor="#00CC99" ><div align="center" class="style5"> INSERT NEW RECORD </div></td>

<pre></pre>
<?php include('server.php'); 

// fetch the record to be updated
if (isset($_GET['edit'])) {
	$id = $_GET['edit'];
	$edit_state = true;
	$rec = mysqli_query($db, "SELECT * FROM instructordata WHERE cid=$cid");
	$record = mysqli_fetch_array($rec);
	$instructorid = $record['instructorid'];
	$fname = $record['fname'];
	$mname = $record['mname'];
	$lname = $record['lname'];
	$gender = $record['gender'];
	$date = $record['date'];
	$login_time = $record['login_time'];
	$logout_time = $record['logout_time'];
	$cid = $record['cid'];

}

?>
<!DOCTYPE html>
<html>
<head>
<title>Holy</title>
    <link rel="stylesheet" type="text/css" href="style1.css">
    <style type="text/css">
    body {
	background-image: url(login_images/sad.jpg);
}
    </style>
<meta charset="utf-8">
</head>
<body>



<form method="post" action="server.php" >
    <input type="hidden" name="id" value="<?php echo $id; ?>">
		<div class="input-group">
			<label>Instructor ID:</label>
			<input type="text" name="instructorid" placeholder="Instructor ID" value="<?php echo $instructorid; ?>">
		</div>
		<div class="input-group">
			<label>First Name:</label>
			<input type="text" name="fname" placeholder="First Name" value="<?php echo $fname; ?>">
		</div>
        <div class="input-group">
			<label>Middle Name:</label>
			<input type="text" name="mname" placeholder="Middle Name" value="<?php echo $mname; ?>">
		</div>
        <div class="input-group">
			<label>Last Name:</label>
			<input type="text" name="lname" placeholder="Last Name" value="<?php echo $lname; ?>">
		</div>
        <div class="input-group">
			<label>Gender:</label>
			<input type="text" name="gender" placeholder="Gender" value="<?php echo $gender; ?>">
		</div>
        <div class="input-group">
			<label>Date:</label>
			<input type="text" name="date" placeholder="Date" value="<?php echo $date; ?>">
		</div>
        <div class="input-group">
			<label>Login Time:</label>
			<input type="text" name="login_time" placeholder="Login Time" value="<?php echo $login_time; ?>">
		</div>
        <div class="input-group">
			<label>Logout Time:</label>
			<input type="text" name="logout_time" placeholder="Logout Time" value="<?php echo $logout_time; ?>">
		</div>
		<div class="input-group">
        <?php if ($edit_state == false): ?>
        <button type="submit" name="save" class="btn">Insert</button>
        <?php else: ?>
        <button type="submit" name="update" class="btn">Update</button>
        <?php endif ?>
			
		</div>
</form>



<body>
<?php if (isset($_SESSION['message'])): ?>
<div class="msg">
		<?php 
			echo $_SESSION['message']; 
			unset($_SESSION['message']);
		?>
	</div>
<?php endif ?>
	<table width="66%" align="center">
			<thead>
<tr>
  <table width="1301" border="2" align="center" cellpadding="5" cellspacing="2">
	<tr bgcolor="#00CC99" class="instructorid">
            	<th bgcolor="#00CC99">instructorid</th>
                <th bgcolor="#00CC99">fname</th>
                <th bgcolor="#00CC99">mname</th>
                <th bgcolor="#00CC99">lname</th>
                <th bgcolor="#00CC99">gender</th>
                <th bgcolor="#00CC99">date</th>
                <th bgcolor="#00CC99">login time</th>
                <th bgcolor="#00CC99">logout time</th>
                <th colspan="7" bgcolor="#00CC99">Action</th>
    </tr>
				</thead>
              <tbody>
              		<?php while ($row = mysqli_fetch_array($results)) { ?>
					<tr>
                		<td><?php echo $row['instructorid']; ?></td>
                   	 	<td><?php echo $row['fname']; ?></td>
                    	<td><?php echo $row['mname']; ?></td>
                    	<td><?php echo $row['lname']; ?></td>
                    	<td><?php echo $row['gender']; ?></td>>
                    	<td><?php echo $row['date']; ?></td>
                    	<td><?php echo $row['login_time']; ?></td>
                        <td><?php echo $row['logout_time']; ?></td>
                    	<td bgcolor="#FFFFFF">
                    	<a class="edit_btn" href="body.php?update=<?php echo $row['cid']; ?>">Edit</a>
                        </td>
                        <td>
                        <a class="del_btn" href="server.php?del=<?php echo $row['cid']; ?>">Delete</a>
                    </td>
                   </tr>
					<?php } ?>
              	
              </tbody>
  </table>
<a href="logout.php"><img src="assets/logout.jpg" width="41" height="41" alt="logout button"></a>
<tr>
</body>



</table>	
</body>
</html>