<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width", initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>hahahah</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
	<table id="main" border="0" cellspacing="0">
    	<tr>
        	<td id="header">
            	<h1>Search in PHP</h1>
            </td>
        </tr>
        <tr>
        	<td id="table-form">
            	<form action="search.php" method="get">
                	Search : <input type="text" name="" value="search">
                    <input type="submit" name="" value="search">
                </form>
            </td>
        </tr>
        <tr>
        	<td id="table-data">
            	<table cellpadding="10px">
</body>
