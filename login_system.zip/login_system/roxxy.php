<!DOCTYPE html>
<html>
<head>
	<title>Search Bar using PHP</title>
</head>
<body>

<form method="post">
<label>Search</label>
<input type="text" name="search">
<input type="submit" name="submit">
	
</form>

</body>
</html>

<?php

$con = new PDO("mysql:host=localhost;dbname=learningmods",'root','');

if (isset($_POST["submit"])) {
	$str = $_POST["search"];
	$sth = $con->prepare("SELECT * FROM `instructordata` WHERE instructorid = '$str'");

	$sth->setFetchMode(PDO:: FETCH_OBJ);
	$sth -> execute();

	if($row = $sth->fetch())
	{
		?>
		<br><br><br>
		<table>
			<tr>
				<th>instructorid</th>
				<th>fname</th>
                <th>lname</th>
                <th>mname</th>
                <th>gender</th>
                <th>date</th>
                <th>login_time</th>
                <th>logout_time</th>
			</tr>
			<tr>
				<td><?php echo $row->instructorid; ?></td>
				<td><?php echo $row->fname;?></td>
                <td><?php echo $row->mname; ?></td>
                <td><?php echo $row->lname; ?></td>
                <td><?php echo $row->gender; ?></td>
                <td><?php echo $row->date; ?></td>
                <td><?php echo $row->login_time; ?></td>
                <td><?php echo $row->logout_time; ?></td>
			</tr>

		</table>
<?php 
	}
		
		
		else{
			echo "Name Does not exist";
		}


}

?>