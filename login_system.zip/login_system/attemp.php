<?php
$sqllist = "Select * from users where user_name='".$POST['user_name']."'";
$result=mysql_query($sqllist)or die (mysql_error());
$error=mysql_error(); print $error;

while($row=mysql_fetch_array($result))
{
$a=$row['attemp'];
$t1=$row['attemp']+1;

$sqlupdate = "UPDATE users SET attemp='".$t1."'
		where user_name='" .$_POST['user_name']. "'";
		mysql_query($sql);

}